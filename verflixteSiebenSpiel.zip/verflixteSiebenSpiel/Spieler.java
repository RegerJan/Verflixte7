/**
 * Klasse Spieler mit Fehlern
 * 
 * @author David Tepa�e
 * @version 02
 * 
 */

 
public class Spieler  
{
 /**
  * Eine Person kennt zwei W�rfel und den Topf:
  */ 
 
   private   Wuerfel wuerfel1;
   private   Wuerfel wuerfel2;
   private   Topf topf;
   
  /** 
  * Hier folgen die Attribute der Klasse Spieler:
  */
  
   private String name;
   protected int punkte;
   private int vermoegen;
   protected int wurfAnzahl;
   protected boolean darfWuerfeln;

   /**
    * Konstruktor f�r Objekte der Klasse Spieler
    * Mit der folgenden Methode wird ein Objekt der Klasse Spieler hergestellt.
   */
    public Spieler(Wuerfel pWuerfel1, Wuerfel pWuerfel2, Topf pTopf)
    {
        this.wuerfel1 = pWuerfel1;
        this.wuerfel2 = pWuerfel2;
        this.topf = pTopf;
        this.vermoegen = 1000;
    }
    
    /**
     * Der aktuelle Durchgang wird beendet, auch wenn keine Sieben gew�rfelt wurde.
     * Das W�rfelrecht des Spielers erlischt.
     */
    public void durchgangBeenden()
    {
        this.darfWuerfeln = false;
    }

   /**
    * Die bis dahin erreichte Punktesumme wird zur�ckgegeben.
    * @return Die bis dahin erreichte Punktsumme des Spielers
    */
   public int punktestandAngeben ()
   {
       return this.punkte;
   }


   /**
    * Der Spieler erh�lt den derzeit im Topf befindlichen Einsatz. Der Durchgang ist beendet.
    */
   public void topfLeeren ()
   {
       if(!darfWuerfeln)
       {
        this.vermoegen = this.vermoegen + this.topf.einsatzAbgeben();
        this.punkte = 0;
        this.wurfAnzahl = 0;
       }
       else
       {
           System.out.println("Beende bitte zun�chst den Durchgang.");
       }
   }

   /**
    * @return Die Anzahl der W�rfe im aktuellen Durchgang
    */
   public int wurfAnzahlAngeben ()
   {
      return this.wurfAnzahl;
   }

   /**
    * Ein gewisser Anteil des Verm�gens des Spielers wird in den Topf gelegt.
    * @param einsatz Der Einsatz, der gesetzt werden soll.
    */
   public void einsatzSetzen (int einsatz)
   {
    if (this.vermoegen < einsatz)
        {
            einsatz = this.vermoegen;
        } 
        this.topf.einsatzAufnehmen(einsatz);
        this.vermoegen=this.vermoegen-einsatz;
        this.darfWuerfeln = true;               //Nur wer einen Einsatz gesetzt hat, darf auch spielen.
   }

   /**
    * Der Spieler w�rfelt mit beiden W�rfeln. Falls er keine Sieben w�rfelt, wird die Augensumme auf seine aktuelle Punktzahl addiert. 
    * Falls er eine Sieben w�rfelt, wird die Augensumme subtrahiert.
    */
   public void wuerfeln ()
   {
       if(darfWuerfeln)
       {
         wuerfel1.rollen();
         wuerfel2.rollen();
         int augensumme = wuerfel1.punktzahlAngeben()+wuerfel2.punktzahlAngeben();
         if(augensumme != 7)
         {
             this.punkte = this.punktestandAngeben()+augensumme;
             System.out.println("aktueller Wurf: "+ augensumme + "/ neuer Punktestand: " + this.punkte);
         }
         else
         {
             this.punkte = this.punktestandAngeben()-augensumme;
             this.darfWuerfeln = false;
             System.out.println("aktueller Wurf: "+ augensumme + "/ neuer Punktestand: " + this.punkte);
         }
         this.wurfAnzahl++;
        }
        else
        {
            System.out.println("Du darfst nicht mehr w�rfeln.");
        }
    }
 
   /**
    * @param neuerName Der neue Name des Spielers
    */
   public void setName (String neuerName)
   {
         this.name = neuerName;
   }
   
   public String getName()
   {
       return this.name;
    }
}

